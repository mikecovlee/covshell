#include "cslplug.h"


namespace csl
{
	class c_clear;
	static c_clear *me;
}


class csl::c_clear:public baseShellFunc
{
  public:
	c_clear()
	{
		m_name = "clear";
		shell->regist_func(this);
	}
	int exec(const std::string &);
};


void csl::plugin::install()
{
	csl::this_plugin.name("CSL Clear");
	me = new csl::c_clear;
}


void csl::plugin::uninstall()
{
	delete me;
}


int csl::c_clear::exec(const std::string & cmd)
{
	ioctrl->clrscr();
	return 0;
}