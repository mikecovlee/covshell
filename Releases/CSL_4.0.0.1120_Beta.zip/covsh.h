#include "csl.cpp"


namespace csl
{
	class c_plug;
	class c_lang;
	static basic_lang language;
	static basic_shell shell;
	static basic_io ioctrl;
}


int csl::basic_shell::exec(const std::string & in)
{
	std::string func, cmd;
	int i;
	for (i = 0; in[i] != ' ' && i < in.size(); ++i)
		func += in[i];
	for (++i; i < in.size(); ++i)
		cmd += in[i];
  for (auto & i:func_list)
		if (func == i->name())
			return i->exec(cmd);
	if (in.size() != 0)
		std::cout << language.find(language.language(), "shell.unknow_command") << std::endl;
}


bool csl::basic_io::open(const std::string & file)
{
	void *bundle = dlopen(file.c_str(), RTLD_LAZY);
	if (bundle)
	{
		baseShellPlug *(*entry) () = (baseShellPlug * (*)())dlsym(bundle, "entry");
		plug_bundle[entry()] = bundle;
		entry()->construct(language, shell, ioctrl);
		m_plugins.push_back(entry()->name());
		return true;
	}
	return false;
}


void csl::basic_io::init()
{
	inflow.open(config_direct + "plugins.config");
	if (!inflow)
		std::cout << "Open Config File Error!" << std::endl;
	std::string line;
	while (std::getline(inflow, line))
	{
		if (line[0] == '#')
			continue;
		open(config_direct + line);
	}
}


csl::baseShellFunc::baseShellFunc():m_name("Basic_Shell_Function")
{
	shell.regist_func(this);
}


csl::baseShellFunc::~baseShellFunc()
{
	shell.remove_func(this);
}


class csl::c_plug:public baseShellFunc
{
  public:
	c_plug()
	{
		m_name = "plug";
		shell.regist_func(this);
	}
	int exec(const std::string &);
};


class csl::c_lang:public baseShellFunc
{
  public:
	c_lang()
	{
		m_name = "lang";
		shell.regist_func(this);
	}
	int exec(const std::string &);
};