#include "covsh.h"


int csl::c_plug::exec(const std::string & cmd)
{
	using namespace std;
	auto v = split(cmd);
	if (v.size() == 0)
	{
		cout << language.find(language.language(), "shell.plug.now") << endl;
	  for (auto & it:ioctrl.plugins())
			cout << it << endl;
		return 0;
	}
	cout << language.find(language.language(), "shell.too_many_parameters") << endl;
	return 0;
}


int csl::c_lang::exec(const std::string & cmd)
{
	using namespace std;
	auto v = split(cmd);
	if (v.size() == 0)
	{
		cout << language.find(language.language(), "shell.lang.now") << endl;
		return 0;
	}
	if (v.size() == 1 && findchar(v[0], '-') == 0)
	{
		if (language.language(v[0]))
		{
			cout << language.find(language.language(), "shell.lang.now") << endl;
			return 0;
		}
		else
		{
			cout << language.find(language.language(), "shell.lang.unknow") << endl;
			return 0;
		}
	}
	int params = 0;
	std::string param;
	bool list_support = false;
  for (auto & it:v)
	{
		if (findchar(it, '-') != 0)
		{
			if (it == "-support")
			{
				list_support = true;
			}
			else
			{
				cout << language.find(language.language(), "shell.unknow_parameters") << endl;
				return 0;
			}
		}
		else
		{
			++params;
			if (params > 1)
			{
				cout << language.find(language.language(), "shell.too_many_parameters") << endl;
				return 0;
			}
			param = it;
		}
	}
	cout << language.find(language.language(), "shell.lang.support") << ':' << endl;
  for (auto & it:language.languages())
		cout << it << endl;
	if (params > 0)
	{
		if (language.language(param))
		{
			cout << language.find(language.language(), "shell.lang.now") << endl;
			return 0;
		}
		else
		{
			cout << language.find(language.language(), "shell.lang.unknow") << endl;
			return 0;
		}
	}
}


int csl::basic_shell::run(int args, char **argv)
{
	using namespace std;
	c_plug plug;
	c_lang lang;
	ioctrl.clrscr();
	language.init();
	ioctrl.init();
	cout << "Covariant Shell " << version << endl;
	bool exit = false;
	while (!exit)
	{
		if (m_echo)
			cout << home << '>';
		string line;
		getline(cin, line);
		exec(line);
	}
	return 0;
}


int main(int args, char **argv)
{
	return csl::shell.run(args, argv);
}