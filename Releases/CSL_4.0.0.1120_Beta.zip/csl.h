#include <map>
#include <list>
#include <vector>
#include <string>
#include <dlfcn.h>
#include <fstream>
#include <iostream>
#include <termios.h>


namespace csl
{
	const char *version = "4.0.0.1120 Beta";
	inline std::vector < std::string > split(const std::string &);
	inline int findchar(const std::string &, char);
	class basic_lang;
	class baseShellFunc;
	class baseShellPlug;
	class basic_shell;
	class basic_io;
}


class csl::basic_lang
{
  protected:
	std::string m_lang;
	std::string config_direct = "language/";
	std::ifstream inflow;
	std::list < std::string > langs;
	std::map < std::string, std::map < std::string, std::string >> data_base;
	void entry_db();
  public:
	basic_lang() = default;
	basic_lang(const std::string & dir):config_direct(dir)
	{
	}
	void init()
	{
		entry_db();
		m_lang = *langs.begin();
	}
	bool language(const std::string & in)
	{
		bool find = false;
	  for (auto & it:langs)
			if (it == in)
				find = true;
		if (find)
			m_lang = in;
		return find;
	}
	const std::string & language()
	{
		return m_lang;
	}
	const std::list < std::string > &languages()
	{
		return langs;
	}
	std::string find(const std::string &, const std::string &);
};


class csl::baseShellFunc
{
  protected:
	std::string m_name;
  public:
	baseShellFunc();
	baseShellFunc(const baseShellFunc &) = delete;
	virtual ~ baseShellFunc();
	virtual int exec(const std::string & cmd)
	{
	}
	virtual const std::string & name()
	{
		return m_name;
	}
};


class csl::baseShellPlug
{
  protected:
	std::string m_name;
	void (*plug_construct) (basic_lang *, basic_shell *, basic_io *);
	void (*plug_destory) ();
  public:
	baseShellPlug():m_name("Basic_Shell_Plugin")
	{
		plug_construct = 0;
		plug_destory = 0;
	}
	baseShellPlug(const baseShellPlug &) = delete;
	virtual ~ baseShellPlug()
	{
		destory();
	}
	virtual void construct(void (*func) (basic_lang *, basic_shell *, basic_io *))
	{
		plug_construct = func;
	}
	virtual void construct(basic_lang & lang, basic_shell & sh, basic_io & io)
	{
		if (plug_construct)
			plug_construct(&lang, &sh, &io);
	}
	virtual void destory(void (*func) ())
	{
		plug_destory = func;
	}
	virtual void destory()
	{
		if (plug_destory)
			plug_destory();
	}
	virtual void name(const std::string & in)
	{
		m_name = in;
	}
	virtual const std::string & name()
	{
		return m_name;
	}
};


class csl::basic_shell
{
  protected:
	bool m_echo = true;
	std::list < baseShellFunc * >func_list;
  public:
#if not defined(__ANDROID__) || defined(ANDROID)
	std::string shelldir = "/root/.covsh/";
	std::string home = "/root/";
#else
	std::string shelldir = "/mnt/sdcard/.covsh/";
	std::string home = "/mnt/sdcard/";
#endif
	bool echo()
	{
		return m_echo;
	}
	void echo(bool in)
	{
		m_echo = in;
	}
	void regist_func(baseShellFunc * it)
	{
		func_list.push_back(it);
	}
	void remove_func(baseShellFunc * it)
	{
		func_list.remove(it);
	}
	int exec(const std::string &);
	int run(int, char **);
};


class csl::basic_io
{
  protected:
	std::string config_direct = "plugin/";
	std::ifstream inflow;
	std::list < std::string > m_plugins;
	std::map < baseShellPlug *, void *>plug_bundle;
  public:
	~basic_io()
	{
	  for (auto & it:plug_bundle)
		{
			it.first->destory();
			dlclose(it.second);
		}
	}
	bool open(const std::string &);
	const std::list < std::string > &plugins()
	{
		return m_plugins;
	}
	inline void clrscr();
	inline void pause();
	inline void echo(bool);
	void init();
};