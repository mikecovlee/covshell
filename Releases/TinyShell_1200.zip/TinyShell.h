#ifndef GUARD_TinyShell_h
#define GUARD_TinyShell_h
  // TinyShell 头文件 1.2.0
  // 版权所有 2015 © T&C Studio
  // 李登淳编写
  // 感谢@不一样的井猜
#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<map>
#include<time.h>
#include<stdio.h>
#include<termios.h>
#include<dirent.h>
#include<sys/stat.h>
int findchar(const std::string chars, char ch) {
  for (int i = 0; i != chars.size(); ++i) {
    if (chars[i] == ch) {
      return i + 1;
    }
  }
  return 0;
}
bool findfile(std::string dir) {
  std::ifstream in(dir);
  if (in) {
    return true;
  } else {
    return false;
  }
}
void rmdir(const std::string & d) {
  dirent **dstr;
  if (!opendir(d.c_str())) {
    std::cerr << "rmdir: 目录不存在！";
    return;
  }
  int n = scandir(d.c_str(), &dstr, 0, alphasort);
  std::string file;
  while (n-- != 2) {
    file += d + "/" + dstr[n]->d_name;
    if (remove(file.c_str()))
      rmdir(file);
    file.erase(file.begin(), file.end());
    free(dstr[n]);
  }
  free(dstr);
  if (remove(d.c_str()))
    std::cerr << "rmdir:错误！无法删除目录";;
}
void type(const std::string & f) {
  std::ifstream fin(f.c_str());
  std::string str;
  if (!fin.is_open())
    std::cerr << "文本文件不存在！" << std::endl;
  else {
    while (!fin.eof()) {
      getline(fin, str);
      std::cout << str << std::endl;
    }
  }
  fin.close();
}
bool findspace(const std::string & chars) {
  typedef std::string::size_type string_size;
  for (string_size i; i != chars.size(); ++i) {
    if (!std::isspace(chars[i])) {
      return false;
    }
  }
  return true;
}
namespace variable {
  static std::map < std::string, int >vary_int;
  static std::map < std::string, std::string > vary;
  void create(std::string vary_name, std::string vary_value) {
    vary[vary_name] = vary_value;
    return;
  }
  void create(std::string vary_name, int vary_value) {
    vary_int[vary_name] = vary_value;
    return;
  }
  bool read(std::string vary_name, std::string & return_value) {
    if (vary.find(vary_name) == vary.end())
      return false;
    return_value = vary.find(vary_name)->second;
    return true;
  }
  bool read(std::string vary_name, int &return_value) {
    if (vary_int.find(vary_name) == vary_int.end())
      return false;
    return_value = vary_int.find(vary_name)->second;
    return true;
  }
  bool write(std::string vary_name, std::string vary_value) {
    if (vary.find(vary_name) == vary.end())
      return false;
    vary[vary_name] = vary_value;
    return true;
  }
  bool write(std::string vary_name, int vary_value) {
    if (vary_int.find(vary_name) == vary_int.end())
      return false;
    vary_int[vary_name] = vary_value;
    return true;
  }
}
void getvalue(std::string & str) {
  std::string tmp;
  std::string::size_type first = 0;
  std::string::size_type last = 0;
  int i = 0;
for (const char &ch:str)
    if (ch == '%')
      i++;
  i /= 2;
  while (i--) {
    first = str.find('%', last);
    last = str.find('%', first + 1) + 1;
    if (variable::read(str.substr(first, last - first), tmp))
      str.replace(first, last - first, tmp);
  }
}
void date() {
  static const std::string months[] =
    { "1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月",
    "9月", "10月", "11月", "12月"
  };
  static const std::string weekdays[] =
    { "星期日", "星期一", "星期二", "星期三", "星期四",
    "星期五",
    "星期六"
  };
  time_t t;
  time(&t);
  tm *tn = localtime(&t);
  std::cout << tn->tm_year +
    1900 << "年" << months[tn->
                            tm_mon] << tn->tm_mday << "日 " << weekdays[tn->
                                                                         tm_wday];
}
void time() {
  time_t t;
  time(&t);
  tm *tn = localtime(&t);
  std::cout << ((tn->tm_hour < 10) ? "0" : "") << tn->tm_hour << ':' <<
    ((tn->tm_min < 10) ? "0" : "") << tn->tm_min << ':' << ((tn->tm_sec <
                                                             10) ? "0" : "") <<
    tn->tm_sec;
}
void dir(const std::string & d) {
  dirent **dstr;
  if (!opendir(d.c_str())) {
    std::cerr << "dir:错误！目录不存在";
    return;
  }
  int n = scandir(d.c_str(), &dstr, 0, alphasort);
  for (int i = 0; i < n; i++) {
    std::cout << dstr[i]->d_name << std::endl;
    free(dstr[i]);
  }
  free(dstr);
}
std::vector < std::string > split(const std::string & s) {
  std::vector < std::string > input;
  typedef std::string::size_type string_size;
  string_size i = 0;
  while (i != s.size()) {
    while (i != s.size() && std::isspace(s[i]))
      ++i;
    string_size j = i;
    while (j != s.size() && !std::isspace(s[j]))
      ++j;
    if (i != j) {
      input.push_back(s.substr(i, j - i));
      i = j;
    }
  }
  return input;
}
void clean() {
  printf("\x1B[2J\x1B[0;0f");
}
void cpause() {
  termios newt;
  tcgetattr(0, &newt);
  newt.c_lflag &= ~ICANON;
  newt.c_lflag &= ~ECHO;
  tcsetattr(0, TCSANOW, &newt);
  std::cin.get();
  newt.c_lflag |= ICANON;
  newt.c_lflag |= ECHO;
  tcsetattr(0, TCSANOW, &newt);
}
#endif